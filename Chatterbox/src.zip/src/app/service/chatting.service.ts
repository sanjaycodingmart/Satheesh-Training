import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class ChattingService {

  constructor(private http:HttpClient) { }
  Chat=(user)=>{
    return this.http.get(`http://localhost:5003/usernames?token=${localStorage.getItem('userDetails')}&username=${user.username}`)
  }
  ChatterBox=(token)=>{
    return this.http.get(`http://localhost:5003/name?token=${token}`)
  }
  Recvrdetails=(id)=>{
    return this.http.get(`http://localhost:5003/details?id=${id}`)
  }
  
}
