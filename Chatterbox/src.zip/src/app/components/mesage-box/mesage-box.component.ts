import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mesage-box',
  templateUrl: './mesage-box.component.html',
  styleUrls: ['./mesage-box.component.css']
})
export class MesageBoxComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
    