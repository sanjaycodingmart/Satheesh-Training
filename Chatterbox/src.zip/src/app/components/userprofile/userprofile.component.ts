import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit {

  @Input() userProfile: any

  constructor( private router:Router) { }

  ngOnInit(): void {
  }
  OnlogOut = () => {
    console.log('object')
    localStorage.removeItem('userDetails');
    this.router.navigate(['/signin'])
  }
}
