import { Component, OnInit } from '@angular/core';
import { ChattingService } from '../../../service/chatting.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-search-bar',
  templateUrl: './search-bar.component.html',
  styleUrls: ['./search-bar.component.css']
})
export class SearchBarComponent implements OnInit {
  user={
    username:''
  }
  friends;
  constructor(private chat:ChattingService,private router:Router) { }

  ngOnInit(): void {
    if(!localStorage.getItem('userDetails')){
      this.router.navigate(['/signin']);
    }
    
  }
  onChange=async(event)=>{
    console.log(event.target.value)
    this.user.username=event.target.value
      if(!(event.target.value=='')){
        await this.chat.Chat(this.user).subscribe(data=>{
          this.friends=data;
          console.log(this.friends)
          if(this.friends==401){
            localStorage.removeItem('userDetails')
            this.router.navigate(['/signin'])
          }
        })
    }

  }
  getChats=async(event)=>{
    console.log(event.target.id);
    
  }
}
