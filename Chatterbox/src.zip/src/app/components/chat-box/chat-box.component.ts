import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
// import { Socket } from 'ngx-socket-io'
import { SocketioService } from '../../socketio.service';
import { async } from '@angular/core/testing';
@Component({
  selector: 'app-chat-box',
  templateUrl: './chat-box.component.html',
  styleUrls: ['./chat-box.component.css']
})
export class ChatBoxComponent implements OnInit {

  @Input() user: any
  @Input() userId: any
  message: '';
  recid:any;
  data: any;
  constructor(private router: ActivatedRoute, private socketService: SocketioService) {
    router.params.subscribe( (params) => {
      console.log(params)
      this.recid=params.id
      this.socketService.getMessages(params.id).subscribe(data=>{
        console.log(data)
      })
    
    })
   
  }

 
  sendMessage = async (recid, usrid) => {
    this.data = {
      msg: this.message,
      recvId: recid,
      usrId: usrid
    }
    await this.socketService.listen(this.data.recvId, this.data)
  }
}
