import { Injectable, OnInit } from '@angular/core';
import { Socket } from 'ngx-socket-io';
import { Observable } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class SocketioService implements OnInit {
  messages = [];
  constructor(private socket: Socket) {

  }
  ngOnInit() {

  }
  getMessages=(id)=> {
    console.log('object',id)
    if(id){
      console.log("socket service",id)
      return this.socket.fromEvent(id.toString())
    }
}

  listen = (id, data) => {
    return this.socket.emit(id.toString(), {
      message: data.msg,
      senderid: data.usrId,
      receiverid: data.recvId
    })
  }

}
